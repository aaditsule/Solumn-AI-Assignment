#!/usr/bin/env bash
set -eu

python3 /tests/grade.py
